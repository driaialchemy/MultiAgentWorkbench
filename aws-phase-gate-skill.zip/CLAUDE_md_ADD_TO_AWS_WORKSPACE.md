<!--
HOW TO USE THIS FILE:
This is content to place in the CLAUDE.md file at the ROOT of your AWS workspace:
C:\Users\msell\OneDrive\aialchemyrepos\aws\CLAUDE.md

If that file does not exist yet, create it and paste this whole thing in.
If it already exists (e.g. from running /init), paste this section in underneath
whatever /init generated. Delete this comment block before saving.
-->

## Governed Agentstack AWS Migration — Standing Rules

Core rule: **No charter, no run.** This must remain a testable behavior everywhere, not just a description.

- This project completes one governed layer at a time (AWS-6 through AWS-12). Never do more than one phase's work in a single response.
- Work only under `C:\Users\msell\OneDrive\aialchemyrepos\aws` unless a phase explicitly authorizes coordinated source changes (only AWS-9 onward may touch source).
- The source project lives at `C:\Users\msell\OneDrive\aialchemyrepos\agentstack` — do not modify it during AWS-6, AWS-7, or AWS-8.
- Source Phases 1–6 must stay green. Do not add source Phase 7.
- No real client data, ever.
- Locked topology only: Lambda, API Gateway HTTP API, DynamoDB, S3, CloudWatch Logs, IAM. Nothing else — no VPC/NAT, EC2, ECS/Fargate, Bedrock, RDS, OpenSearch, SageMaker, or Step Functions.
- Never run `cdk deploy`, `cdk bootstrap`, `sam deploy`, `terraform apply`, or any mutating AWS CLI command without explicit authorization given in that conversation.
- Never configure AWS credentials before the controlled deploy phase (AWS-10).
- To run a phase, use the skill: `/aws-phase-gate <phase-number>` (6 through 12). Always end a phase with a final report only — no starting the next phase in the same response.
