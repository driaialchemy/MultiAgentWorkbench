# Setup — 3 steps, about 5 minutes

## 1. Copy the skill folder into your AWS workspace

Copy the whole `.claude` folder (with `skills/aws-phase-gate/` inside it, containing `SKILL.md` and the 7 `phase-*.md` files) into:

```
C:\Users\msell\OneDrive\aialchemyrepos\aws\.claude\
```

End result should look like:
```
C:\Users\msell\OneDrive\aialchemyrepos\aws\.claude\skills\aws-phase-gate\SKILL.md
C:\Users\msell\OneDrive\aialchemyrepos\aws\.claude\skills\aws-phase-gate\phase-6.md
C:\Users\msell\OneDrive\aialchemyrepos\aws\.claude\skills\aws-phase-gate\phase-7.md
... through phase-12.md
```

## 2. Set up CLAUDE.md in the AWS workspace

Open (or create) this file:
```
C:\Users\msell\OneDrive\aialchemyrepos\aws\CLAUDE.md
```

Paste in the contents of `CLAUDE_md_ADD_TO_AWS_WORKSPACE.md` (delete the comment block at the top first). If you don't have a CLAUDE.md yet, you can also just run `/init` inside Claude Code Desktop first to generate a starter one, then paste this section underneath it.

## 3. Use it

Open Claude Code Desktop, make sure you're pointed at the AWS workspace folder, and type:

```
/aws-phase-gate 6
```

That runs AWS-6 only, following the exact boundaries and definition-of-done from your workflow doc, ending in a final report. Next session, run `/aws-phase-gate 7`, and so on through 12.

For AWS-10 and AWS-12 (the two phases that touch real AWS resources), the skill will stop and ask you to explicitly confirm before it runs any deploy/destroy command — it will not do this automatically.
