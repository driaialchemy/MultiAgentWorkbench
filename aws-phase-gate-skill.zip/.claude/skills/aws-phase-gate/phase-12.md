# AWS-12 — Teardown and Repeatability Proof

**Purpose:** Show that the demo can be safely deployed, destroyed, and recreated without orphaned costly resources.

**Boundary:** `cdk destroy` and the redeploy that follows are both account-mutating. Both require explicit authorization from the person before running. If that approval has not been clearly given in this conversation, stop and ask before proceeding.

**Primary commands**
```
cd C:\Users\msell\OneDrive\aialchemyrepos\aws
cdk destroy
# After verification and explicit approval for redeploy:
cdk deploy
```

**Work items**
- Export or save sample evidence artifacts if needed, before destroying anything.
- Run `cdk destroy` after explicit authorization.
- Confirm API Gateway, Lambda, DynamoDB, S3, CloudWatch, and IAM cleanup behavior.
- Confirm retained resources are intentional and documented.
- Redeploy once after destroy to prove repeatability.
- Run smoke tests again after redeploy.
- Update final README and CURRENT_HANDOFF.md.

**Tests and checks**
- Stack destroys successfully.
- No unexpected resources remain.
- Redeploy succeeds.
- Smoke tests pass after redeploy.
- Cost exposure remains minimal and documented.

**Definition of done**
- Deploy works. Smoke test works. Destroy works. Redeploy works.
- No orphaned costly resources.
- Final README and handoff are updated.
