# AWS-10 — First Controlled AWS Deploy

**Purpose:** Deploy the minimum backend only after AWS-6 through AWS-9 pass locally and after explicit deployment authorization.

**Boundary:** This phase is the first account-mutating phase. It requires explicit approval from the person before running `cdk deploy` or any mutating command. If that approval has not been clearly given in this conversation, stop and ask for it before proceeding past the pre-deploy checks.

**Primary commands**
```
cd C:\Users\msell\OneDrive\aialchemyrepos\aws
python -m pytest tests/ -v
cdk synth
cdk deploy
```

**Work items**
- Confirm MFA is enabled.
- Confirm non-root deploy identity is used.
- Confirm budget alert is configured.
- Confirm AWS region is intentionally selected.
- Confirm there are no pre-existing expensive resources running.
- Run tests and `cdk synth` immediately before deploy.
- Run `cdk deploy` only after explicit authorization.
- Run endpoint smoke tests immediately after deploy.
- Inspect the AWS console for created resources and cost exposure.

**Tests and checks**
- GET /health returns success.
- Incomplete charter blocks in AWS.
- Missing accountability owner blocks in AWS.
- Complete charter runs in AWS.
- Audit appears in DynamoDB.
- Evidence appears in S3.
- CloudWatch logs exist with limited retention.
- Denied services are absent.

**Definition of done**
- One blocked run in AWS.
- One successful governed run in AWS.
- Audit visible in DynamoDB. Evidence visible in S3.
- No denied services created.
- Budget alert remains safe.
