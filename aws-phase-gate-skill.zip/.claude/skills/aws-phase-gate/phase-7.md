# AWS-7 — Governed Backend API Endpoints

**Purpose:** Expose the governed workflow through Lambda/API Gateway while preserving the source governance model.

**Boundary:** This phase proves the runtime contract before persistence migration. Do not implement AWS storage adapters or Streamlit integration unless this phase explicitly extends scope. No deploy, no real AWS calls, no credentials, no source project changes.

**Work items**
- Implement `GET /health`.
- Implement `POST /charter/validate`.
- Implement `POST /workflows/run`.
- Implement `GET /runs/{run_id}`.
- Implement `GET /runs/{run_id}/audit`.
- Implement `GET /runs/{run_id}/evidence`.
- Keep API Gateway as a thin front door, not an orchestrator.
- Return structured result envelopes for allowed and blocked runs.

**Tests and checks**
- test_health_endpoint_returns_200
- test_validate_charter_blocks_missing_fields
- test_validate_charter_blocks_missing_owner
- test_run_blocks_incomplete_charter
- test_run_allows_complete_charter
- test_run_returns_structured_result_envelope
- test_run_preserves_no_charter_no_run
- test_no_agent_to_agent_messaging
- test_api_gateway_is_only_front_door_not_orchestrator

**Definition of done**
- All endpoint tests pass locally.
- Incomplete charter blocks execution.
- Missing accountability owner blocks execution.
- Complete charter allows synthetic governed workflow.
- No real AWS calls. No deploy.
