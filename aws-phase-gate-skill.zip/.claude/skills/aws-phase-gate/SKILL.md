---
name: aws-phase-gate
description: Use when working on the AWS migration for the governed agentstack project (phases AWS-6 through AWS-12). Enforces the completion workflow's global execution rules and runs exactly one phase at a time, ending with a final report only. Invoke as /aws-phase-gate 6 (or 7, 8, 9, 10, 11, 12).
argument-hint: [phase-number 6-12]
---

# AWS Phase Gate

You are executing ONE phase of the AWS Governed Agentstack Completion Workflow. Core rule for the whole project: **No charter, no run.**

## Step 1 — Load the correct phase file

The phase number is given as an argument ($1). Before doing anything else, read the matching file in this skill's folder:

- `6` → `phase-6.md`
- `7` → `phase-7.md`
- `8` → `phase-8.md`
- `9` → `phase-9.md`
- `10` → `phase-10.md`
- `11` → `phase-11.md`
- `12` → `phase-12.md`

If no phase number was given, or it's not 6–12, stop and ask which phase to run. Do not guess.

## Step 2 — Global execution rules (apply to every phase, no exceptions)

- Work only under `C:\Users\msell\OneDrive\aialchemyrepos\aws` unless the loaded phase file explicitly authorizes coordinated source changes.
- Do not modify the source project (`C:\Users\msell\OneDrive\aialchemyrepos\agentstack`) during AWS-6, AWS-7, or AWS-8.
- Keep source Phases 1–6 behavior intact and source tests green.
- Do not add source Phase 7.
- Do not use real client data.
- Do not add new architecture or services beyond the locked topology (Lambda, API Gateway HTTP API, DynamoDB, S3, CloudWatch Logs, IAM).
- Do not run `cdk deploy`, `cdk bootstrap`, `sam deploy`, `terraform apply`, or any mutating AWS CLI command unless the loaded phase file is AWS-10 or AWS-12 AND the person has given explicit authorization in this conversation to proceed with that specific mutating command.
- Do not configure AWS credentials until the controlled deploy phase (AWS-10).
- Preserve "No charter, no run" as a runtime gate and as a testable behavior in everything you build or check.
- Do exactly the work listed for this one phase. Do not start the next phase's work items.

## Step 3 — Do the work

Follow the "Work items" and run the "Tests and checks" listed in the loaded phase file. Stop and flag to the person if anything requires stepping outside this phase's boundary.

## Step 4 — Final report only

End your response with a final report and nothing else beyond it — no extra exploration, no starting the next phase. The report must include, in this order:

1. Commands run
2. Files changed
3. Tests run and their results
4. Any phase-specific results called out in the loaded phase file (e.g., synth result, denied-service checks, deploy confirmation)
5. Explicit confirmation of what was NOT done (e.g., "no AWS resources were created," "source project untouched")
6. Definition-of-done checklist from the phase file, marked complete or incomplete

After the report, tell the person this phase is finished and that a new session (`/clear`) is recommended before starting the next phase.
