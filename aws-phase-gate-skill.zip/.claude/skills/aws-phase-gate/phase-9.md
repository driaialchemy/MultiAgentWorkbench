# AWS-9 — Streamlit Backend Adapter

**Purpose:** Allow the existing Streamlit demo UI to call either the local workflow or the AWS API backend.

**Boundary:** This is the first phase that may require coordinated source changes. Keep changes narrow. No deploy required yet.

**Work items**
- Add a backend mode configuration: `BACKEND_MODE=local` or `BACKEND_MODE=aws`.
- Add `AWS_API_BASE_URL` for AWS mode.
- Default to local mode.
- Show the active backend mode in the UI.
- Block AWS mode clearly if `AWS_API_BASE_URL` is missing.
- Do not silently fall back from AWS to local if AWS API calls fail.
- Preserve the same charter validation, audit, and evidence concepts in the UI.

**Tests and checks**
- test_backend_mode_defaults_to_local
- test_aws_mode_requires_api_base_url
- test_streamlit_adapter_calls_validate_charter
- test_streamlit_adapter_calls_run_workflow
- test_streamlit_adapter_handles_api_error_cleanly
- test_streamlit_adapter_does_not_bypass_charter_gate

**Definition of done**
- Local UI still works.
- AWS mode is configurable.
- Source tests still pass. AWS tests still pass.
- No deploy required yet.
