# AWS-11 — Evidence and Governance Demo Validation

**Purpose:** Prove the AWS implementation tells the same governance story as the local Streamlit reference.

**Boundary:** This phase validates the portfolio proof, not new functionality. No new features. No source Phase 7 features.

**Work items**
- Run missing charter field scenario.
- Run missing accountability owner scenario.
- Run complete charter happy path.
- Run unauthorized or disabled skill scenario if implemented in the AWS path.
- Confirm blocked paths return clear failure classification and recommended action.
- Confirm successful paths create ordered audit events.
- Confirm evidence artifacts are created and retrievable.
- Update the demo script or AWS README with the validated AWS walkthrough.

**Tests and checks**
- Blocked run shows policy/gate reason.
- Successful run shows agent, skill, policy, gate, audit, checkpoint, and evidence trail.
- Evidence is human-readable.
- Audit events are ordered and attributable.
- No source Phase 7 features are introduced.

**Definition of done**
- AWS demo matches the local governance story.
- Every blocked path returns a clear reason.
- Every successful path creates audit/evidence.
- No external APIs. No real client data.
