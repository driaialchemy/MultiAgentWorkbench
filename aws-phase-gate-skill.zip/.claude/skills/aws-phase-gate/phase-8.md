# AWS-8 — DynamoDB and S3 Storage Adapters

**Purpose:** Move audit, run state, checkpoint, incident, dead-letter, and evidence persistence into AWS-native storage while preserving local fallback and mocked testability.

**Boundary:** Storage migration should preserve evidence readability and audit traceability. No deploy, no real AWS credentials, no real AWS calls, no source project changes, no new architecture.

**Work items**
- Create or refine a storage adapter boundary so workflow code does not call boto3 directly everywhere.
- Map audit events and run metadata to DynamoDB.
- Map evidence JSON/Markdown and report artifacts to S3.
- Keep local fallback behavior when AWS environment variables are missing.
- Use moto for all DynamoDB and S3 integration tests.

**Tests and checks**
- test_audit_event_written_to_mock_dynamodb
- test_run_record_written_to_mock_dynamodb
- test_checkpoint_written_to_mock_dynamodb
- test_dead_letter_metadata_written_to_mock_dynamodb
- test_evidence_json_written_to_mock_s3
- test_evidence_markdown_written_to_mock_s3
- test_no_real_aws_call_escapes_mock
- test_local_fallback_still_works_when_env_missing

**Definition of done**
- Local fallback still works.
- Moto integration tests pass.
- No real AWS calls. No credentials required. No deploy.

**Storage mapping reference**

Recommended DynamoDB single-table shape:
```
Table: governed-agentstack-runtime
PK: RUN#<run_id>
SK: META
SK: AUDIT#<timestamp>#<event_id>
SK: CHECKPOINT#<checkpoint_id>
SK: MEMORY#<memory_id>
SK: DEADLETTER#<event_id>
SK: INCIDENT#<incident_id>
```

Recommended S3 key layout:
```
evidence/<run_id>/governance_summary.json
evidence/<run_id>/governance_summary.md
reports/<run_id>/report.json
artifacts/<run_id>/<artifact_name>
dead-letter/<run_id>/<event_id>.json
```
