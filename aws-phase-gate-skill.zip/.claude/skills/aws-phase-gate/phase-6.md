# AWS-6 — Infrastructure Synth Validation

**Purpose:** Validate the CDK app locally and inspect the synthesized infrastructure template without creating AWS resources.

**Boundary:** AWS-6 does not implement endpoints, storage adapters, or Streamlit integration. No deploy, no bootstrap, no AWS resource creation.

**Primary commands**
```
cd C:\Users\msell\OneDrive\aialchemyrepos\aws
python -m pytest tests/ -v
cdk synth
```

**Work items**
- Run the AWS workspace test suite before synth.
- Run local `cdk synth` only (this phase authorizes local synth, nothing else).
- Inspect the generated template for the approved services only.
- Add or confirm static tests that fail if denied services appear.
- Confirm S3 public access block, CloudWatch log retention, and scoped IAM permissions.
- Update `README.md` and `CURRENT_HANDOFF.md` in the AWS workspace with results.

**Tests and checks**
- pytest passes in the AWS workspace.
- `cdk synth` passes locally.
- Template contains Lambda, API Gateway HTTP API, DynamoDB, S3, CloudWatch Logs, and IAM only.
- Denied-service tests cover VPC, NAT, EC2, ECS/Fargate, Bedrock, RDS, OpenSearch, SageMaker, and Step Functions.

**Definition of done**
- AWS tests pass.
- `cdk synth` passes.
- Synth template reviewed and documented.
- No deploy, no bootstrap, no AWS resource creation.
- AWS workspace handoff and README updated.
